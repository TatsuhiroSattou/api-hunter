/**
 * Prueba cada endpoint descubierto con un Origin "ajeno" (uno que el servidor
 * nunca debería confiar) y revisa si lo refleja en Access-Control-Allow-Origin.
 * Si además manda Access-Control-Allow-Credentials: true, cualquier sitio
 * controlado por un atacante podría leer la respuesta usando la sesión de la
 * víctima (robo de datos cross-origin, no solo lectura "local").
 *
 * Esto SOLO observa cómo responde el servidor a un Origin arbitrario — no
 * monta ningún ataque real, es el mismo tipo de prueba que ya venías
 * haciendo a mano con curl.
 */

const EVIL_ORIGIN = 'https://evil-attacker-controlled.example';

export async function checkCors(url, { fetchImpl = fetch, method = 'GET', extraHeaders = {} } = {}) {
  const result = {
    url,
    tested: false,
    reflectsArbitraryOrigin: false,
    allowsCredentialsWithReflectedOrigin: false,
    allowOriginHeader: null,
    allowCredentialsHeader: null,
    verdict: null,
  };

  try {
    const res = await fetchImpl(url, {
      method,
      headers: { Origin: EVIL_ORIGIN, ...extraHeaders },
    });
    result.tested = true;
    const allowOrigin = res.headers.get('access-control-allow-origin');
    const allowCreds = res.headers.get('access-control-allow-credentials');
    result.allowOriginHeader = allowOrigin;
    result.allowCredentialsHeader = allowCreds;

    if (allowOrigin === EVIL_ORIGIN || allowOrigin === '*') {
      result.reflectsArbitraryOrigin = true;
    }
    if (result.reflectsArbitraryOrigin && allowOrigin !== '*' && String(allowCreds).toLowerCase() === 'true') {
      result.allowsCredentialsWithReflectedOrigin = true;
    }

    if (result.allowsCredentialsWithReflectedOrigin) {
      result.verdict = 'CRÍTICO: refleja cualquier Origin Y permite credentials — cualquier sitio puede robar datos de la sesión de la víctima.';
    } else if (allowOrigin === '*') {
      result.verdict = 'Access-Control-Allow-Origin: * (sin credentials, impacto depende de si la respuesta trae datos sensibles sin auth).';
    } else if (result.reflectsArbitraryOrigin) {
      result.verdict = 'Refleja un Origin arbitrario sin validarlo contra una lista blanca — revisar impacto.';
    } else {
      result.verdict = 'No refleja el Origin de prueba (no parece vulnerable a este check).';
    }
  } catch (e) {
    result.verdict = `No se pudo probar: ${e.message}`;
  }

  return result;
}

export async function checkCorsForEndpoints(urls, opts = {}) {
  const uniqueUrls = [...new Set(urls)];
  const results = [];
  for (const url of uniqueUrls) {
    results.push(await checkCors(url, opts));
  }
  return results;
}
