#!/usr/bin/env node
import yargs from 'yargs';
import { hideBin } from 'yargs/helpers';
import { writeFile, mkdir } from 'node:fs/promises';
import { crawlSite } from './crawler.js';
import { discoverAllJsFiles } from './jsCrawler.js';
import { extractFromDiscoveredJs } from './jsExtractor.js';
import { buildEndpointInventory } from './endpointAnalyzer.js';
import { checkCorsForEndpoints } from './corsChecker.js';
import { writeReport } from './report.js';
import { isKatanaAvailable, runKatana } from './katanaRunner.js';

const argv = yargs(hideBin(process.argv))
  .usage('api-hunter --url <target> [opciones]')
  .option('url', { type: 'string', demandOption: true, describe: 'URL objetivo (debes tener autorización para probarla)' })
  .option('max-pages', { type: 'number', default: 15 })
  .option('cookie', { type: 'string', describe: 'Cookie de sesión para crawl autenticado, ej: "session=abc123"' })
  .option('out', { type: 'string', default: './api-hunter-output' })
  .option('headless', { type: 'boolean', default: true })
  .option('check-cors', { type: 'boolean', default: true, describe: 'Probar cada endpoint único con un Origin ajeno para detectar CORS mal configurado' })
  .option('max-js-files', { type: 'number', default: 150, describe: 'Límite total de .js a descubrir/descargar (BFS recursivo, incluye chunks referenciados por otros JS)' })
  .option('js-depth', { type: 'number', default: 6, describe: 'Profundidad máxima siguiendo referencias JS→JS (import() dinámico, chunks, etc.)' })
  .option('insecure', { type: 'boolean', default: false, describe: 'Como "curl -k": ignora certificados TLS inválidos/autofirmados. Muchos objetivos internos los tienen.' })
  .option('use-katana', { type: 'boolean', default: true, describe: 'Usar el binario real de katana (si está instalado) como motor de descubrimiento principal, en vez de solo nuestro crawler casero' })
  .option('katana-headless', { type: 'boolean', default: false, describe: 'Pedirle a katana que use Chrome headless (más lento, pero ve rutas/JS que solo aparecen tras ejecutar la SPA)' })
  .option('katana-jsluice', { type: 'boolean', default: false, describe: 'Pedirle a katana que use jsluice (parsing de JS a nivel AST, más preciso que regex — más memoria/tiempo)' })
  .option('katana-depth', { type: 'number', default: 3, describe: 'Profundidad de crawl de katana' })
  .help()
  .argv;

async function main() {
  // --insecure tiene que aplicarse ANTES de cualquier fetch/https — afecta
  // tanto al fetch nativo de Node (jsCrawler.js, corsChecker.js) como a
  // Playwright (que recibe el flag aparte, vía ignoreHTTPSErrors).
  if (argv.insecure) {
    process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    console.log('[!] --insecure activo: NO se valida el certificado TLS del objetivo (como curl -k). Úsalo solo contra objetivos autorizados.');
  }

  const headers = {};
  if (argv.cookie) headers.Cookie = argv.cookie;

  // Reporta en vivo cada fetch que falle, en vez de tragárselo en silencio
  // y que el único síntoma sea "se encontraron 0 archivos JS".
  const fetchErrors = [];
  const onFetchError = (url, reason) => {
    fetchErrors.push({ url, reason });
    console.warn(`[!] No se pudo descargar ${url} → ${reason}`);
  };

  console.log(`[*] Crawleando ${argv.url} (máx ${argv.maxPages} páginas)...`);
  const { pagesVisited, apiCalls, jsFiles, pagesHtml } = await crawlSite(argv.url, {
    maxPages: argv.maxPages,
    headers,
    headless: argv.headless,
    insecure: argv.insecure,
  });

  console.log(`[*] Páginas visitadas: ${pagesVisited.length}`);
  console.log(`[*] Llamadas XHR/fetch capturadas: ${apiCalls.length}`);
  console.log(`[*] Archivos JS vistos durante el crawl dinámico: ${jsFiles.length}`);

  // --- katana: motor de descubrimiento principal, si está disponible -----
  // En vez de confiar solo en nuestro crawler casero (Playwright visitando
  // páginas + regex de JS→JS), se le pasa el trabajo pesado de descubrir
  // TODO (páginas, .js, y los endpoints que su propio parser de JS ya
  // encuentra) a katana, que es un crawler real y maduro. Lo que katana NO
  // hace — puntuar candidatos a IDOR mirando nombres de campo en el body —
  // lo seguimos haciendo nosotros abajo, sobre cada .js que katana aporte.
  let katanaJsFiles = [];
  let katanaOtherUrls = [];
  const katanaAvailable = argv.useKatana && isKatanaAvailable();
  if (argv.useKatana && !katanaAvailable) {
    console.log('[!] katana no está instalado (o no está en PATH) — se sigue solo con el crawler propio.');
    console.log('    Para instalarlo: go install github.com/projectdiscovery/katana/cmd/katana@latest');
    console.log('    o bajar el binario de https://github.com/projectdiscovery/katana/releases');
  }
  if (katanaAvailable) {
    console.log(`[*] Corriendo katana (motor real de crawling, profundidad=${argv.katanaDepth}${argv.katanaHeadless ? ', headless' : ''}${argv.katanaJsluice ? ', jsluice' : ''})...`);
    const katanaResult = await runKatana(argv.url, {
      depth: argv.katanaDepth,
      headless: argv.katanaHeadless,
      jsluice: argv.katanaJsluice,
      cookie: argv.cookie,
      knownFiles: 'all',
    });
    katanaJsFiles = katanaResult.jsFiles;
    katanaOtherUrls = katanaResult.otherUrls;
    if (katanaResult.exitInfo.timedOut) {
      console.log('[!] katana se cortó por tiempo límite (sitio grande) — se usa lo que alcanzó a encontrar.');
    }
    if (katanaResult.exitInfo.code !== 0 && katanaResult.exitInfo.stderrTail) {
      console.log(`[!] katana terminó con código ${katanaResult.exitInfo.code}. Últimas líneas de stderr:\n${katanaResult.exitInfo.stderrTail}`);
    }
    console.log(`[*] katana encontró ${katanaJsFiles.length} archivos .js y ${katanaOtherUrls.length} URLs adicionales.`);
  }

  console.log('[*] Descubriendo TODOS los .js del sitio (semilla del crawl + katana + robots.txt + referencias JS→JS recursivas)...');
  const discoveredJs = await discoverAllJsFiles(argv.url, {
    seedJsFiles: [...new Set([...jsFiles, ...katanaJsFiles])],
    pagesHtml,
    fetchImpl: (u) => fetch(u, { headers }), // propaga la cookie de sesión también al pedir JS (hay JS servido solo autenticado)
    maxJsFiles: argv.maxJsFiles,
    maxDepth: argv.jsDepth,
    onFetchError,
  });
  console.log(`[*] Archivos JS descubiertos en total: ${discoveredJs.jsFiles.length} (crawl dinámico: ${jsFiles.length} · katana: ${katanaJsFiles.length} · tras recursión propia: ${discoveredJs.jsFiles.length})`);

  console.log('[*] Analizando cada archivo JS, uno por uno, en busca de endpoints...');
  const jsEndpoints = extractFromDiscoveredJs(discoveredJs);
  console.log(`[*] Endpoints extraídos de JS estático: ${jsEndpoints.length}`);
  if (discoveredJs.jsFiles.length && jsEndpoints.length === 0 && fetchErrors.length) {
    console.log(`[!] Se descubrieron ${discoveredJs.jsFiles.length} .js pero ninguno se pudo descargar/analizar (${fetchErrors.length} fallos de red arriba). Revisa si el objetivo necesita --insecure o una --cookie válida.`);
  }

  // katana también devuelve URLs que su propio parser de JS (-jc) encontró
  // y que NO terminan en .js (ej. rutas /api/... vistas dentro de un
  // bundle) — se suman como tráfico adicional, igual que las llamadas
  // XHR/fetch que capturó el crawler dinámico, para que pasen por el mismo
  // análisis de IDOR.
  const apiCallsWithKatana = [
    ...apiCalls,
    ...katanaOtherUrls.map((u) => ({ method: u.method, url: u.url, status: undefined, postData: null, fromPage: u.source })),
  ];

  const inventory = buildEndpointInventory({ apiCalls: apiCallsWithKatana, jsEndpoints });
  const candidates = inventory.filter((e) => e.isIdorCandidate);
  console.log(`[*] Endpoints únicos totales: ${inventory.length}`);
  console.log(`[*] Candidatos a IDOR/BOLA: ${candidates.length}`);

  let corsResults = [];
  if (argv.checkCors) {
    console.log('[*] Probando CORS en endpoints únicos con un Origin ajeno...');
    const uniqueUrls = inventory.map((e) => e.url).filter((u) => u.startsWith('http'));
    corsResults = await checkCorsForEndpoints(uniqueUrls);
    const risky = corsResults.filter((r) => r.reflectsArbitraryOrigin);
    console.log(`[*] Endpoints con CORS sospechoso: ${risky.length}`);
  }

  await mkdir(argv.out, { recursive: true });
  const jsonPath = `${argv.out}/inventory.json`;
  const htmlPath = `${argv.out}/report.html`;

  await writeFile(jsonPath, JSON.stringify({ target: argv.url, pagesVisited, inventory, corsResults, fetchErrors, katanaUsed: katanaAvailable }, null, 2));
  await writeReport(inventory, { target: argv.url, pagesVisited: pagesVisited.length }, htmlPath, corsResults);

  console.log(`[+] JSON guardado en: ${jsonPath}`);
  console.log(`[+] Reporte HTML guardado en: ${htmlPath}`);
}

main().catch((err) => {
  console.error('[!] Error:', err);
  process.exit(1);
});
