/**
 * Integración con katana (https://github.com/projectdiscovery/katana), el
 * crawler real de ProjectDiscovery — en vez de mantener nuestro propio clon
 * a medias. katana resuelve cosas que jsCrawler.js (nuestro módulo casero)
 * no puede:
 *
 *  - Crawling headless real (Chrome) para SPAs que renderizan rutas/scripts
 *    dinámicamente, no solo el HTML inicial.
 *  - Parsing de JS con heurísticas mucho más maduras que nuestros regex
 *    (`-jsl`/jsluice hace parsing real a nivel AST, no regex de texto).
 *  - robots.txt + sitemap.xml automático (`-kf all`).
 *  - Mejor manejo de red en general (reintentos, rate-limit, etc).
 *
 * Lo que katana NO hace y por lo que seguimos necesitando nuestro propio
 * código encima de sus resultados:
 *
 *  - No puntúa nada como candidato a IDOR/BOLA — solo descubre URLs.
 *  - No mira nombres de campo dentro del body de las llamadas POST/PUT
 *    (nuestra heurística de endpointAnalyzer.js + jsExtractor.js sigue
 *    siendo la que detecta "cedula"/"id_usuario"/etc. en el código).
 *
 * Por eso el flujo queda: katana descubre TODO (páginas + .js + endpoints
 * ya vistos en JS) → nosotros bajamos cada .js que katana encontró (más lo
 * que nuestro propio jsCrawler.js sume por su cuenta como red de
 * seguridad) → corremos jsExtractor.js/endpointAnalyzer.js sobre cada uno,
 * uno por uno, igual que antes.
 */

import { spawn, spawnSync } from 'node:child_process';
import readline from 'node:readline';

const JS_EXT_RE = /\.m?js(\?|#|$)/i;

function looksLikeJsUrl(url) {
  try {
    return JS_EXT_RE.test(new URL(url).pathname.split('/').pop() || '');
  } catch {
    return JS_EXT_RE.test(url.split('/').pop() || '');
  }
}

/** true si el binario `katana` está instalado y es ejecutable. No lanza. */
export function isKatanaAvailable() {
  try {
    const res = spawnSync('katana', ['-version'], { timeout: 5000 });
    // katana imprime la versión en stderr en algunas builds, así que basta
    // con que el proceso haya podido arrancar (no ENOENT).
    return res.error == null;
  } catch {
    return false;
  }
}

/**
 * Corre `katana` contra targetUrl y parsea su salida JSONL línea por línea
 * (streaming — no espera a que termine todo el crawl para empezar a leer,
 * así un sitio grande no se traduce en "nada hasta el final").
 *
 * Devuelve:
 *  - jsFiles: string[]                 → .js que katana encontró (páginas,
 *                                         <script src>, Y los que su propio
 *                                         parser de JS (-jc/-jsl) detectó
 *                                         referenciados desde otro JS)
 *  - otherUrls: {method,url,source}[]  → todo lo demás que katana vio
 *                                         (formularios, XHR si -xhr, rutas
 *                                         de API devueltas por el parser de
 *                                         JS que NO terminan en .js) — se
 *                                         pueden sumar al inventario como
 *                                         tráfico adicional, igual que los
 *                                         apiCalls que captura crawler.js
 *  - raw: object[]                     → cada línea ya parseada, por si se
 *                                         quiere inspeccionar algo más
 *  - exitInfo: {code, timedOut, stderrTail}
 */
export function runKatana(
  targetUrl,
  {
    depth = 3,
    headless = false,
    systemChrome = false,
    jsluice = false,
    knownFiles = 'all',
    xhr = false,
    cookie = null,
    headers = [],
    insecure = false, // no existe un flag -k explícito; katana ya no valida TLS por defecto, esto solo documenta la intención
    concurrency = 10,
    timeoutSec = 10,
    maxRuntimeMs = 5 * 60 * 1000,
    binaryPath = 'katana',
  } = {}
) {
  const args = [
    '-u', targetUrl,
    '-d', String(depth),
    '-jc', // endpoint parsing/crawling dentro de JS
    '-jsonl',
    '-silent',
    '-duc', // no perder tiempo chequeando actualizaciones de katana contra internet
    '-or', '-ob', // sin raw/body completo: solo necesitamos la lista de URLs, no bajar el contenido vía katana
    '-c', String(concurrency),
    '-timeout', String(timeoutSec),
  ];
  if (knownFiles) args.push('-kf', knownFiles);
  if (jsluice) args.push('-jsl'); // parsing a nivel AST (más preciso, más lento/memoria)
  if (xhr && headless) args.push('-xhr'); // solo tiene efecto en modo headless
  if (headless) {
    args.push('-hl');
    if (systemChrome) args.push('-sc');
    args.push('-nos'); // --no-sandbox: necesario corriendo como root en CI/contenedores
  }
  if (cookie) args.push('-H', `Cookie: ${cookie}`);
  for (const h of headers) args.push('-H', h);

  return new Promise((resolve) => {
    const jsFiles = new Set();
    const otherUrls = [];
    const raw = [];
    let stderrTail = '';
    let timedOut = false;

    // detached:true pone a katana en su propio grupo de procesos — sin esto,
    // algunas terminales/orquestadores (notado en pruebas dentro de este
    // mismo entorno) le reenvían una señal al grupo completo apenas arranca
    // y katana la interpreta como Ctrl+C, cortando el crawl de inmediato
    // con cero resultados. Con process group propio, esa señal ya no lo toca.
    const child = spawn(binaryPath, args, { stdio: ['ignore', 'pipe', 'pipe'], detached: true });

    const killTimer = setTimeout(() => {
      timedOut = true;
      try {
        process.kill(-child.pid, 'SIGTERM'); // mata todo el grupo (katana + el Chrome que lance si -hl está activo)
      } catch {
        child.kill('SIGTERM');
      }
    }, maxRuntimeMs);

    const rl = readline.createInterface({ input: child.stdout });
    rl.on('line', (line) => {
      const trimmed = line.trim();
      if (!trimmed) return;
      let obj;
      try {
        obj = JSON.parse(trimmed);
      } catch {
        return; // línea no-JSON (banner, warning suelto) — se ignora
      }
      raw.push(obj);

      // katana anida bajo "request"/"response"; se tolera también una
      // variante aplanada ("request.endpoint") por si algún wrapper/versión
      // futura cambia el formato — más barato que fallar en silencio.
      const req = obj.request || {};
      const endpoint = req.endpoint || obj['request.endpoint'];
      const method = (req.method || obj['request.method'] || 'GET').toUpperCase();
      const source = req.source || obj['request.source'] || null;
      if (!endpoint) return;

      if (looksLikeJsUrl(endpoint)) {
        jsFiles.add(endpoint);
      } else {
        otherUrls.push({ method, url: endpoint, source });
      }
    });

    child.stderr.on('data', (chunk) => {
      stderrTail = (stderrTail + chunk.toString()).slice(-2000);
    });

    child.on('close', (code) => {
      clearTimeout(killTimer);
      resolve({
        jsFiles: [...jsFiles],
        otherUrls,
        raw,
        exitInfo: { code, timedOut, stderrTail },
      });
    });

    child.on('error', (err) => {
      clearTimeout(killTimer);
      resolve({ jsFiles: [], otherUrls: [], raw: [], exitInfo: { code: null, timedOut: false, stderrTail: String(err) } });
    });
  });
}
