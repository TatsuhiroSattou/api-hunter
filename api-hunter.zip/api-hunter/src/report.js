import { writeFile } from 'node:fs/promises';

function suggestionFor(entry) {
  if (!entry.isIdorCandidate) return null;
  const idParam = entry.idCandidates[0];
  if (idParam.type === 'path') {
    return `Repite la request cambiando "${idParam.value}" en el path por el ID de otro usuario/recurso (uno que no te pertenezca) y compara status/respuesta con una request legítima a tu propio recurso. Prueba también sin token de sesión.`;
  }
  if (idParam.type === 'body') {
    return `Repite la request cambiando "${idParam.param}" en el body por el valor de otra cuenta/persona (que no sea la tuya) manteniendo tu propia sesión/token, y compara la respuesta. Si el campo es un dato sensible (cédula, email, teléfono), evalúa también si el endpoint responde sin autenticación.`;
  }
  return `Repite la request cambiando el parámetro "${idParam.param}=${idParam.value}" por el valor de otro recurso ajeno y compara la respuesta.`;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));
}

function renderCorsSection(corsResults) {
  if (!corsResults || !corsResults.length) return '';
  const risky = corsResults.filter((r) => r.reflectsArbitraryOrigin);
  if (!risky.length) return '<h2>CORS</h2><p>No se encontró reflejo de Origin arbitrario en los endpoints probados.</p>';

  const rows = risky.map((r) => `
    <tr class="${r.allowsCredentialsWithReflectedOrigin ? 'candidate' : ''}">
      <td><code>${escapeHtml(r.url)}</code></td>
      <td>${escapeHtml(r.allowOriginHeader || '')}</td>
      <td>${escapeHtml(r.allowCredentialsHeader || '—')}</td>
      <td>${escapeHtml(r.verdict)}</td>
    </tr>`).join('\n');

  return `
  <h2>CORS mal configurado (${risky.length})</h2>
  <table>
    <thead><tr><th>Endpoint</th><th>Access-Control-Allow-Origin</th><th>Allow-Credentials</th><th>Veredicto</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>`;
}

export function renderHtmlReport(inventory, meta = {}, corsResults = []) {
  const rows = inventory.map((e) => {
    const sugg = suggestionFor(e);
    return `
      <tr class="${e.isIdorCandidate ? 'candidate' : ''}">
        <td>${e.riskScore}</td>
        <td>${escapeHtml(e.method)}</td>
        <td><code>${escapeHtml(e.path)}</code></td>
        <td>${e.origin.join(', ')}</td>
        <td>${e.idCandidates.map((c) => `${c.type === 'path' ? 'path' : c.param}: <code>${escapeHtml(c.value)}</code> (${c.kind})`).join('<br>') || '—'}</td>
        <td>${sugg ? escapeHtml(sugg) : '—'}</td>
      </tr>`;
  }).join('\n');

  return `<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>API Hunter — Reporte</title>
<style>
  :root { color-scheme: light dark; }
  body { font-family: -apple-system, system-ui, sans-serif; margin: 2rem; background:#0f1115; color:#e6e6e6; }
  h1 { font-size: 1.4rem; }
  .meta { color: #9aa0a6; margin-bottom: 1.5rem; font-size: .9rem; }
  table { border-collapse: collapse; width: 100%; font-size: .85rem; }
  th, td { border: 1px solid #333; padding: 6px 10px; text-align: left; vertical-align: top; }
  th { background: #1a1d24; position: sticky; top: 0; }
  tr.candidate { background: rgba(220, 60, 60, 0.12); }
  code { background: #1a1d24; padding: 1px 4px; border-radius: 3px; }
  .legend { margin-bottom: 1rem; font-size: .85rem; color: #9aa0a6; }
</style>
</head>
<body>
  <h1>API Hunter — Inventario de endpoints</h1>
  <div class="meta">
    Objetivo: ${escapeHtml(meta.target || '')} &middot;
    Páginas visitadas: ${meta.pagesVisited ?? '?'} &middot;
    Endpoints totales: ${inventory.length} &middot;
    Candidatos IDOR: ${inventory.filter((e) => e.isIdorCandidate).length}
  </div>
  <div class="legend">Filas resaltadas = tienen al menos un parámetro que parece un identificador de recurso. Riesgo más alto = IDs numéricos secuenciales en path (más fáciles de enumerar).</div>
  <table>
    <thead>
      <tr><th>Riesgo</th><th>Método</th><th>Path</th><th>Origen</th><th>IDs detectados</th><th>Cómo probarlo manualmente</th></tr>
    </thead>
    <tbody>
      ${rows}
    </tbody>
  </table>
  ${renderCorsSection(corsResults)}
</body>
</html>`;
}

export async function writeReport(inventory, meta, outPath, corsResults = []) {
  const html = renderHtmlReport(inventory, meta, corsResults);
  await writeFile(outPath, html, 'utf-8');
  return outPath;
}
