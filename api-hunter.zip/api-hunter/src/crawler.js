import { chromium } from 'playwright';

/**
 * Crawlea un sitio con un navegador real, capturando:
 *  - Todas las requests XHR/fetch (posibles llamadas a API)
 *  - Las URLs de todos los archivos .js cargados (para analizarlos aparte)
 *  - Enlaces internos, para seguir navegando dentro del mismo dominio
 *
 * No envía payloads ni intenta explotar nada: solo observa tráfico normal
 * generado por el uso de la app (y, si le pasas cookies/headers de sesión,
 * también el tráfico autenticado).
 */
export async function crawlSite(startUrl, opts = {}) {
  const {
    maxPages = 15,
    sameOriginOnly = true,
    headers = {},        // ej: { Cookie: 'session=...' } para crawl autenticado
    headless = true,
    waitAfterLoadMs = 1500,
    insecure = false, // equivalente a "curl -k": ignora certificados TLS inválidos/autofirmados
  } = opts;

  const origin = new URL(startUrl).origin;
  const browser = await chromium.launch({ headless });
  const context = await browser.newContext({ extraHTTPHeaders: headers, ignoreHTTPSErrors: insecure });

  const apiCalls = [];      // { method, url, status, resourceType, postData, fromPage }
  const jsFiles = new Set();
  const pagesHtml = new Map(); // url -> HTML ya renderizado (page.content()), para jsCrawler.js
  const visited = new Set();
  const queue = [startUrl];

  context.on('request', () => {}); // placeholder para mantener el context "caliente"

  async function visitPage(page, url) {
    const requestsOnThisPage = [];

    const onRequest = (req) => {
      const rtype = req.resourceType();
      if (rtype === 'script') {
        jsFiles.add(req.url());
      }
      if (rtype === 'xhr' || rtype === 'fetch') {
        requestsOnThisPage.push({
          method: req.method(),
          url: req.url(),
          postData: req.postData() || null,
          resourceType: rtype,
          fromPage: url,
        });
      }
    };

    const onResponse = async (res) => {
      const req = res.request();
      if (req.resourceType() === 'xhr' || req.resourceType() === 'fetch') {
        const match = requestsOnThisPage.find(
          (r) => r.url === req.url() && r.status === undefined
        );
        if (match) match.status = res.status();
      }
    };

    page.on('request', onRequest);
    page.on('response', onResponse);

    try {
      await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    } catch (e) {
      // si networkidle nunca llega (polling, websockets, etc.) seguimos igual
    }
    await page.waitForTimeout(waitAfterLoadMs);

    // intenta interactuar un poco: click en botones visibles para disparar más llamadas XHR
    try {
      const clickable = await page.$$('button, [role="button"], a[href="#"]');
      for (const el of clickable.slice(0, 8)) {
        try {
          await el.click({ timeout: 800 });
          await page.waitForTimeout(300);
        } catch (_) {}
      }
    } catch (_) {}

    const links = await page
      .$$eval('a[href]', (as) => as.map((a) => a.href))
      .catch(() => []);

    // HTML ya renderizado (post-JS): captura <script src> y
    // <link rel="modulepreload"> que el framework inyectó en runtime, no
    // solo lo que vino en el HTML fuente original.
    const renderedHtml = await page.content().catch(() => null);
    if (renderedHtml) pagesHtml.set(url, renderedHtml);

    page.off('request', onRequest);
    page.off('response', onResponse);

    apiCalls.push(...requestsOnThisPage);
    return links;
  }

  while (queue.length && visited.size < maxPages) {
    const url = queue.shift();
    if (visited.has(url)) continue;
    visited.add(url);

    const page = await context.newPage();
    let links = [];
    try {
      links = await visitPage(page, url);
    } finally {
      await page.close();
    }

    for (const link of links) {
      try {
        const u = new URL(link);
        if (sameOriginOnly && u.origin !== origin) continue;
        if (!visited.has(u.href) && !queue.includes(u.href)) {
          queue.push(u.href);
        }
      } catch (_) {}
    }
  }

  await browser.close();

  return {
    pagesVisited: [...visited],
    apiCalls,
    jsFiles: [...jsFiles],
    pagesHtml,
  };
}
