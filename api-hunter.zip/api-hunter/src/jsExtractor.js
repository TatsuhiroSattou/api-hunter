/**
 * Busca en el código fuente de cada .js patrones típicos de endpoints de API
 * que a veces NUNCA se llegan a disparar en el crawl dinámico (rutas usadas
 * solo en ciertos flujos, feature flags, roles admin, etc.)
 */

// Encuentra CUALQUIER string literal del archivo (simple, doble o template literal),
// sin importar qué tan largo o con qué se concatene.
const STRING_LITERAL_REGEX = /(['"`])((?:\\.|(?!\1)[^\\\n])*)\1/g;

// Dentro del CONTENIDO de cada string literal, busca el patrón de ruta de API
// en CUALQUIER posición (no solo al inicio) — esto es clave para template
// literals tipo `${baseUrl}/api/usuarios/buscar/${cedula}`, donde el path real
// no empieza pegado a la comilla sino después de una interpolación ${...}.
// (?<![\w]) evita matches a mitad de una palabra (ej. no capturar "api" dentro
// de "capital"). La barra inicial sigue siendo opcional por el caso Kento
// (concatenación con base URL que ya termina en "/").
const KEYWORD_PATH_INNER_REGEX = /(?<![a-zA-Z0-9_])(?:\/)?(?:api|v[0-9]+|rest|graphql|internal|admin|method|service|servicio|ws|rpc)[a-zA-Z0-9\-_\/{}:.$]*/gi;

// Llamadas a fetch('...'), axios.get('...'), $.ajax({url:'...'}), o cualquier
// variante de cliente HTTP tipo Angular/jQuery: this.http.post(...), $http.get(...),
// httpClient.put(...). El primer argumento puede venir precedido de una
// concatenación con la base URL (this.API_URL+"...") en vez de ser un string puro.
// El grupo 1 es el VERBO (si el regex lo distingue; fetch/.ajax no traen uno
// explícito en la firma, se infiere después mirando el objeto de opciones) y
// el grupo 2 es la URL — se usa para decidir si vale la pena buscar un body
// (solo importa en POST/PUT/PATCH/DELETE, un GET no suele llevar JSON body).
const CALL_REGEX =
  /(?:\bfetch|axios\.(get|post|put|delete|patch)|\.ajax|\.?https?\.(get|post|put|delete|patch))\s*\(\s*(?:[\w$]+(?:\.[\w$]+)*\s*\+\s*)?["'`]([^"'`]+)["'`]/gi;

// Busca el body de la llamada HTTP DENTRO de su propia lista de argumentos
// — ya sea pasado directo como 2do/3er argumento ({cedula:e,...}) o envuelto
// en JSON.stringify({...}), que es el patrón típico de fetch() nativo:
//   fetch(url, { method:"POST", headers:{...}, body: JSON.stringify({cedula:e}) })
// Solo extrae NOMBRES de campo (no valores: el código minificado no trae
// valores reales, son variables) para cruzarlos contra ID_NAME_HINTS.
//
// OJO: antes esto usaba una "ventana" de N caracteres después de la llamada,
// que en una llamada SIN body (ej. fetch(`.../buscar/${cedula}`), sin 2do
// argumento) terminaba leyendo el objeto de la SIGUIENTE llamada HTTP del
// archivo y le atribuía campos que no eran suyos (contaminación cruzada).
// Por eso ahora se hace bracket-matching real: se delimita el texto a
// exactamente los argumentos de ESTA llamada (desde su "(" hasta su ")" que
// cierra, contando profundidad de paréntesis) y solo se busca el objeto ahí
// adentro — si la llamada no tiene body, el texto delimitado no tiene
// ningún objeto que mirar y no se contamina con lo que venga después.
const STRINGIFY_OBJ_REGEX = /JSON\.stringify\(\s*\{([^{}]*)\}/;
const PLAIN_OBJ_REGEX = /\{([^{}]*)\}/;
const OBJ_KEY_REGEX = /(?:^|[,{(])\s*["'`]?([a-zA-Z_$][\w$]*)["'`]?\s*:/g;
const MAX_CALL_ARGS_SCAN = 2000; // cota de seguridad por si una llamada nunca cierra (código raro/minificado extremo)

function extractCallArgsText(source, openParenIndex) {
  let depth = 0;
  const end = Math.min(source.length, openParenIndex + MAX_CALL_ARGS_SCAN);
  for (let i = openParenIndex; i < end; i++) {
    const ch = source[i];
    if (ch === '(') depth++;
    else if (ch === ')') {
      depth--;
      if (depth === 0) return source.slice(openParenIndex + 1, i);
    }
  }
  return ''; // no se encontró el cierre dentro de la cota: mejor no adivinar
}

function extractBodyKeyHints(source, openParenIndex) {
  const argsText = extractCallArgsText(source, openParenIndex);
  if (!argsText) return [];
  const stringifyMatch = argsText.match(STRINGIFY_OBJ_REGEX);
  const objInner = stringifyMatch ? stringifyMatch[1] : (argsText.match(PLAIN_OBJ_REGEX) || [])[1];
  if (!objInner) return [];
  const keys = new Set();
  for (const km of objInner.matchAll(OBJ_KEY_REGEX)) keys.add(km[1]);
  return [...keys];
}

// Un segmento de path que quedó como "${cedula}" porque vino de un template
// literal (`/api/usuarios/buscar/${cedula}`) no tiene forma de ID (no es un
// número/UUID), pero el NOMBRE de la variable interpolada sí es una pista
// fuerte — "cedula", "userId", "orderId" — igual que un query param.
export const TEMPLATE_PLACEHOLDER_RE = /^\$\{([a-zA-Z_$][\w$]*)\}$/;

// Rutas "de continuación" tipo this.cotizadorUrl+".doctype.cotizacion.cotizacion.insertCotizacion":
// no empiezan con una keyword de API, pero su forma (varios segmentos separados
// por puntos, terminando en algo tipo verbo en camelCase/snake_case) es típica
// de RPC estilo Frappe. Las capturamos aparte para no inflar falsos positivos
// del regex genérico de arriba.
const DOTTED_RPC_REGEX = /["'`](\.[a-zA-Z_][\w]*(?:\.[a-zA-Z_][\w]*){2,})["'`]/g;

// Falsos positivos típicos: nombres de ARCHIVO estático (otro .js, un
// .chunk.js, una imagen, una hoja de estilos) que casualmente empiezan con
// una de las keywords (ej. "admin.chunk.js", "internal-icons.svg") pero no
// son una ruta de API. Si lo que matcheó TERMINA en una de estas
// extensiones, se descarta.
const STATIC_ASSET_EXT_RE = /\.(?:m?js|mjs|css|scss|map|png|jpe?g|gif|svg|webp|ico|woff2?|ttf|eot|json)(?:\?[^/]*)?$/i;

export function extractEndpointsFromSource(source, sourceUrl) {
  // path -> { method, bodyKeyHints: Set }. Un mismo path puede aparecer por
  // varias vías (string suelto Y llamada HTTP con verbo) — se fusiona la
  // metadata en vez de quedarnos solo con la primera ocurrencia.
  const found = new Map();
  const get = (path) => {
    if (!found.has(path)) found.set(path, { method: undefined, bodyKeyHints: new Set() });
    return found.get(path);
  };

  // 1) recorre CADA string/template literal del archivo y, adentro de cada
  //    uno, busca el patrón de ruta en cualquier posición (cubre tanto
  //    "api/method/..." pegado a la comilla como `${base}/api/.../${id}`)
  for (const sm of source.matchAll(STRING_LITERAL_REGEX)) {
    const content = sm[2];
    for (const m of content.matchAll(KEYWORD_PATH_INNER_REGEX)) {
      if (STATIC_ASSET_EXT_RE.test(m[0])) continue; // ej. "admin.chunk.js", no es un endpoint
      get(m[0]);
    }
  }

  // 2) llamadas explícitas a fetch/axios/http.* — aporta el VERBO real
  //    (no forzado a GET) y, si es POST/PUT/PATCH/DELETE, va a buscar el
  //    objeto body cercano para sacar nombres de campo (cedula, user_id...)
  for (const m of source.matchAll(CALL_REGEX)) {
    const url = m[3];
    if (STATIC_ASSET_EXT_RE.test(url)) continue;
    const verb = (m[1] || m[2] || '').toUpperCase() || undefined; // fetch()/.ajax() no traen verbo en la firma
    const entry = get(url);
    if (verb) entry.method = verb;
    // Busca el body SIEMPRE dentro de los argumentos de ESTA llamada (no una
    // ventana de caracteres): si no hay body, extractBodyKeyHints devuelve []
    // sin riesgo de leer la llamada siguiente. Útil incluso para fetch()/
    // .ajax(), que no revelan el verbo en el nombre de la función — el verbo
    // real puede venir como {method:"POST",...} en ese mismo objeto.
    const openParenIdx = m.index + m[0].indexOf('(');
    for (const key of extractBodyKeyHints(source, openParenIdx)) {
      entry.bodyKeyHints.add(key);
    }
  }

  // 3) rutas RPC con puntos tipo Frappe (.doctype.x.y.z)
  for (const m of source.matchAll(DOTTED_RPC_REGEX)) {
    get(m[1]);
  }

  return [...found.entries()].map(([path, meta]) => ({
    path,
    source: sourceUrl,
    method: meta.method,
    bodyKeyHints: [...meta.bodyKeyHints],
  }));
}

export async function fetchAndExtract(jsUrl, fetchImpl = fetch) {
  try {
    const res = await fetchImpl(jsUrl);
    if (!res.ok) return [];
    const text = await res.text();
    return extractEndpointsFromSource(text, jsUrl);
  } catch (e) {
    return [];
  }
}

export async function extractFromAllJsFiles(jsUrls) {
  const results = [];
  for (const url of jsUrls) {
    const found = await fetchAndExtract(url);
    results.push(...found);
  }
  return results;
}

/**
 * Analiza el resultado de jsCrawler.discoverAllJsFiles(): reutiliza el
 * código fuente que ESE módulo ya descargó (no vuelve a pedirlo al
 * servidor) y, si había pistas de sourcemap para ese archivo, las agrega
 * al texto a escanear antes de aplicar los mismos regex de siempre.
 */
export function extractFromDiscoveredJs({ jsFiles = [], sources = new Map(), sourceMapHints = new Map() }) {
  const results = [];
  for (const url of jsFiles) {
    const baseSource = sources.get(url);
    if (!baseSource) continue; // no se pudo descargar (404, timeout, CORS, etc.)
    const hints = sourceMapHints.get(url);
    const combined = hints ? `${baseSource}\n${hints}` : baseSource;
    results.push(...extractEndpointsFromSource(combined, url));
  }
  return results;
}
