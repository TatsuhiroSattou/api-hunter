import { TEMPLATE_PLACEHOLDER_RE } from './jsExtractor.js';

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const NUMERIC_RE = /^\d+$/;
const MONGO_ID_RE = /^[0-9a-f]{24}$/i;
const HASH_LIKE_RE = /^[0-9a-f]{16,40}$/i;

const ID_NAME_HINTS = [
  'id', 'user_id', 'userid', 'uid', 'account', 'account_id', 'order',
  'order_id', 'invoice', 'cart', 'profile', 'ticket', 'doc', 'document',
  'file', 'customer', 'client_id', 'member', 'uuid', 'token', 'ref',
  // identificadores de persona reales, muy comunes en LatAm (cédula, DNI, RUC...)
  'cedula', 'dni', 'ruc', 'rut', 'nit', 'curp', 'passport', 'pasaporte',
  'email', 'phone', 'telefono', 'ide',
];

function segmentLooksLikeId(segment) {
  if (NUMERIC_RE.test(segment)) return { isId: true, kind: 'numérico secuencial', risk: 3 };
  if (UUID_RE.test(segment)) return { isId: true, kind: 'UUID', risk: 1 };
  if (MONGO_ID_RE.test(segment)) return { isId: true, kind: 'Mongo ObjectId', risk: 1 };
  if (HASH_LIKE_RE.test(segment)) return { isId: true, kind: 'hash/token largo', risk: 1 };
  // Segmento NO resuelto porque vino de un template literal: `/buscar/${cedula}`.
  // No hay valor real que mirar (es código estático, no tráfico capturado),
  // pero el NOMBRE de la variable interpolada ya es una pista fuerte si
  // coincide con algo de ID_NAME_HINTS (cedula, userId, orderId...).
  // El parser de URL codifica "{"/"}" como %7B/%7D antes de llegar aquí, así
  // que hay que decodificar el segmento antes de comparar contra el patrón.
  let decoded = segment;
  try { decoded = decodeURIComponent(segment); } catch { /* segmento no es percent-encoding válido */ }
  const placeholder = decoded.match(TEMPLATE_PLACEHOLDER_RE);
  if (placeholder && paramNameLooksLikeId(placeholder[1])) {
    return { isId: true, kind: `nombre de variable interpolada sugiere ID ("${placeholder[1]}")`, risk: 2 };
  }
  return { isId: false };
}

function paramNameLooksLikeId(name) {
  const lower = name.toLowerCase();
  return ID_NAME_HINTS.some((h) => lower === h || lower.endsWith(`_${h}`) || lower.includes(h));
}

/**
 * Analiza una URL (puede ser relativa o absoluta) y devuelve:
 *  - method
 *  - idCandidates: segmentos de path o query params que parecen IDs
 *  - riskScore: heurística simple (mayor = más atractivo para probar IDOR,
 *    con IDs numéricos secuenciales puntuando más alto que UUIDs)
 */
/**
 * Revisa el body de un POST/PUT/PATCH (string JSON, capturado del crawl
 * dinámico) en busca de nombres de campo que parecen identificadores
 * directos de un recurso/persona. Muchas APIs no ponen el ID en la URL
 * sino en el body (ej: {"cedula": "..."}), así que esto es tan importante
 * como revisar path/query.
 */
function findIdLikeFieldsInBody(postData) {
  if (!postData) return [];
  let obj;
  try {
    obj = JSON.parse(postData);
  } catch {
    return []; // no era JSON (form-urlencoded, etc.) — se podría sumar soporte luego
  }
  if (typeof obj !== 'object' || obj === null) return [];

  const hits = [];
  for (const [key, value] of Object.entries(obj)) {
    if (paramNameLooksLikeId(key)) {
      hits.push({ type: 'body', param: key, value: typeof value === 'object' ? JSON.stringify(value) : String(value), kind: 'nombre sugiere ID/dato personal' });
    }
  }
  return hits;
}

/**
 * Igual que findIdLikeFieldsInBody, pero para cuando NO hay tráfico real
 * capturado (nunca se disparó la llamada durante el crawl) y solo tenemos
 * los NOMBRES de campo que el extractor de JS estático sacó del objeto
 * literal pegado a la llamada .post()/.put()/.patch() (jsExtractor.js →
 * bodyKeyHints). Sin valores reales — el código minificado solo trae
 * variables, no datos — pero el nombre del campo ya es la pista.
 */
function findIdLikeFieldsInKeyNames(keys = []) {
  const hits = [];
  for (const key of keys) {
    if (paramNameLooksLikeId(key)) {
      hits.push({
        type: 'body',
        param: key,
        value: '(campo visto en el código fuente JS, sin valor capturado — nunca se disparó la llamada durante el crawl)',
        kind: 'nombre sugiere ID/dato personal (detectado estáticamente)',
      });
    }
  }
  return hits;
}

export function analyzeEndpoint(rawUrl, method = 'GET', postData = null, staticBodyKeyHints = []) {
  let url;
  try {
    url = new URL(rawUrl, 'http://placeholder.local');
  } catch {
    return null;
  }

  const idCandidates = [];
  let riskScore = 0;

  // segmentos del path, ej: /api/users/123/orders/456
  const segments = url.pathname.split('/').filter(Boolean);
  segments.forEach((seg, i) => {
    const check = segmentLooksLikeId(seg);
    if (check.isId) {
      let displayValue = seg;
      try { displayValue = decodeURIComponent(seg); } catch { /* no era percent-encoding */ }
      idCandidates.push({
        type: 'path',
        position: i,
        value: displayValue,
        kind: check.kind,
        precedingSegment: segments[i - 1] || null,
      });
      riskScore += check.risk;
    }
  });

  // query params
  for (const [key, value] of url.searchParams.entries()) {
    const nameHint = paramNameLooksLikeId(key);
    const valueCheck = segmentLooksLikeId(value);
    if (nameHint || valueCheck.isId) {
      idCandidates.push({
        type: 'query',
        param: key,
        value,
        kind: valueCheck.kind || 'nombre sugiere ID',
        risk: valueCheck.isId ? valueCheck.risk : 1,
      });
      riskScore += valueCheck.isId ? valueCheck.risk : 1;
    }
  }

  // campos ID-like en el body (ej: {"cedula": "..."} en un POST), ya sea de
  // tráfico real capturado (postData) o de nombres de campo vistos en el
  // código fuente aunque la llamada nunca se haya disparado en el crawl
  // (staticBodyKeyHints)
  const bodyHits = [
    ...findIdLikeFieldsInBody(postData),
    ...findIdLikeFieldsInKeyNames(staticBodyKeyHints),
  ];
  if (bodyHits.length) {
    idCandidates.push(...bodyHits);
    riskScore += bodyHits.length;
  }

  // métodos que modifican/leen datos de "otro" suelen ser más jugosos
  if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method.toUpperCase())) {
    riskScore += 1;
  }

  return {
    url: rawUrl,
    method: method.toUpperCase(),
    path: url.pathname,
    idCandidates,
    riskScore,
    isIdorCandidate: idCandidates.length > 0,
  };
}

function idCandidateDedupKey(c) {
  return `${c.type}|${c.param ?? ''}|${c.position ?? ''}|${c.value}`;
}

/**
 * Un mismo endpoint suele aparecer VARIAS veces en los resultados crudos: una
 * vez como string suelto (sin verbo ni body — ej. "api/registros" sacado del
 * escaneo genérico de literales) y otra vez vía la llamada HTTP real (con
 * verbo y bodyKeyHints — ej. la URL completa dentro de fetch(...)). Si las
 * dos resuelven a la misma key "MÉTODO path", quedarnos con "lo primero que
 * llegó" descarta en silencio el análisis más rico. Se fusionan los
 * idCandidates (deduplicados) y se sube el riskScore en vez de perderlo.
 */
function mergeAnalyzed(existing, analyzed) {
  const merged = [...existing.idCandidates];
  const seen = new Set(merged.map(idCandidateDedupKey));
  let addedRisk = 0;
  for (const c of analyzed.idCandidates) {
    const dk = idCandidateDedupKey(c);
    if (seen.has(dk)) continue;
    seen.add(dk);
    merged.push(c);
    addedRisk += 1; // aproximación: cada señal nueva y distinta suma al ranking
  }
  return {
    ...existing,
    idCandidates: merged,
    riskScore: Math.max(existing.riskScore, existing.riskScore + addedRisk, analyzed.riskScore),
    isIdorCandidate: merged.length > 0,
  };
}

export function buildEndpointInventory({ apiCalls = [], jsEndpoints = [] }) {
  const byKey = new Map();

  for (const call of apiCalls) {
    const analyzed = analyzeEndpoint(call.url, call.method, call.postData);
    if (!analyzed) continue;
    const key = `${analyzed.method} ${analyzed.path}`;
    const existing = byKey.get(key);
    // mergeAnalyzed hace spread de "existing", así que origin/samples siguen
    // siendo las MISMAS referencias (Set/array) que ya traía existing —
    // mutarlas aquí abajo actualiza el entry fusionado sin pasos extra.
    const entry = existing ? mergeAnalyzed(existing, analyzed) : { ...analyzed, origin: new Set(), samples: [] };
    entry.origin.add('tráfico-dinámico');
    entry.samples.push({ url: call.url, status: call.status, postData: call.postData, fromPage: call.fromPage });
    byKey.set(key, entry);
  }

  for (const js of jsEndpoints) {
    // Antes esto se forzaba a 'GET' sin importar el verbo real de la llamada
    // (this.http.post(...), axios.put(...)), lo que perdía endpoints
    // POST/PUT/PATCH que son justo los más jugosos (modifican/crean datos).
    const method = js.method || 'GET';
    const analyzed = analyzeEndpoint(js.path, method, null, js.bodyKeyHints || []);
    if (!analyzed) continue;
    const key = `${analyzed.method} ${analyzed.path}`;
    const existing = byKey.get(key);
    const entry = existing ? mergeAnalyzed(existing, analyzed) : { ...analyzed, origin: new Set(), samples: [] };
    entry.origin.add('js-estático');
    entry.samples.push({ url: js.path, foundIn: js.source, bodyKeyHints: js.bodyKeyHints || [] });
    byKey.set(key, entry);
  }

  const inventory = [...byKey.values()].map((e) => ({
    ...e,
    origin: [...e.origin],
  }));

  inventory.sort((a, b) => b.riskScore - a.riskScore);
  return inventory;
}
