/**
 * Descubrimiento de JS "estilo Katana": el crawler dinámico (crawler.js)
 * solo ve los .js que el navegador PIDE mientras visita las páginas que
 * alcanzó a recorrer (limitado por --max-pages y por los <a href> que
 * encontró). Eso se queda corto en apps reales porque:
 *
 *  - Hay chunks de code-splitting (webpack "*.chunk.js", Next.js
 *    "_next/static/chunks/*.js", Vite "assets/*.js") que solo se cargan
 *    bajo demanda (ej. al entrar a una ruta admin o abrir un modal) y
 *    puede que el crawl nunca dispare esa acción.
 *  - Un .js puede referenciar a OTROS .js por su cuenta (import()
 *    dinámico, importScripts, manifests de chunks) sin que eso implique
 *    una request de red directamente disparada por la página.
 *  - robots.txt a veces expone rutas de paneles viejos/alternos que el
 *    crawl normal no visita.
 *
 * Este módulo expande la lista de JS semilla (lo que ya vio crawler.js)
 * haciendo BFS: descarga cada .js, busca referencias a más .js adentro, y
 * sigue la cadena hasta agotar la cola o llegar a los límites configurados.
 * No hace fuzzing de wordlist ni fuerza bruta de rutas — solo sigue
 * referencias que YA existen en el código del sitio, en línea con el resto
 * de la herramienta (reconocimiento pasivo, sin generar tráfico de ataque).
 */

const SCRIPT_SRC_HTML_REGEX = /<script[^>]+src=["']([^"']+)["']/gi;
const MODULE_PRELOAD_REGEX = /<link[^>]+rel=["']modulepreload["'][^>]+href=["']([^"']+)["']/gi;

// Referencias a otros .js DENTRO de un .js ya descargado: import() dinámico,
// importScripts() de un worker, o el patrón `src: "..."` / `src = "..."`
// que usan muchos loaders de chunks hechos a mano.
const JS_REF_IN_JS_REGEX =
  /(?:import\(|importScripts\(|\bsrc\s*[:=]\s*)["'`]([^"'`]+?\.m?js(?:\?[^"'`]*)?)["'`]/gi;

// Nombres de archivo de chunk típicos de bundlers modernos, aunque no
// vengan pegados a una llamada import()/src explícita (a veces están
// sueltos dentro de un array/manifest de chunks).
const CHUNK_FILENAME_REGEX =
  /["'`]([\w\-./]*(?:static\/(?:js|chunks)|_next\/static\/chunks|assets)\/[\w\-.]+?\.m?js(?:\?[^"'`]*)?)["'`]/gi;

const SOURCEMAP_COMMENT_REGEX = /\/\/[#@]\s*sourceMappingURL=([^\s]+)/;

function resolveUrl(maybeRelative, baseUrl) {
  try {
    return new URL(maybeRelative, baseUrl).href;
  } catch {
    return null;
  }
}

function looksLikeJs(url) {
  return /\.m?js(\?|#|$)/i.test(url.split('/').pop() || '');
}

async function safeFetchText(url, fetchImpl, onFetchError) {
  try {
    const res = await fetchImpl(url);
    if (!res.ok) {
      onFetchError?.(url, `HTTP ${res.status}`);
      return null;
    }
    return await res.text();
  } catch (err) {
    // Antes esto se tragaba el error sin dejar rastro: si el TLS del
    // objetivo falla (certificado autofirmado/vencido — algo común en
    // infraestructura interna, por eso tantos reportes de bug bounty usan
    // "curl -k") o hay un timeout, el resultado era simplemente "0 JS
    // encontrados" sin ninguna pista de por qué. Ahora se reporta.
    onFetchError?.(url, err?.cause?.code || err?.code || err?.message || String(err));
    return null;
  }
}

/** Referencias a .js dentro de HTML ya renderizado (page.content() de Playwright,
 *  que a diferencia de "ver código fuente" SÍ incluye lo que el framework
 *  inyectó en el DOM en runtime). */
export function extractJsRefsFromHtml(html, baseUrl) {
  const refs = new Set();
  for (const re of [SCRIPT_SRC_HTML_REGEX, MODULE_PRELOAD_REGEX]) {
    for (const m of html.matchAll(re)) {
      const abs = resolveUrl(m[1], baseUrl);
      if (abs && looksLikeJs(abs)) refs.add(abs);
    }
  }
  return refs;
}

/** Referencias a otros .js dentro del código fuente de un .js. */
export function extractJsRefsFromJs(source, baseUrl) {
  const refs = new Set();
  for (const re of [JS_REF_IN_JS_REGEX, CHUNK_FILENAME_REGEX]) {
    for (const m of source.matchAll(re)) {
      const abs = resolveUrl(m[1], baseUrl);
      if (abs && looksLikeJs(abs)) refs.add(abs);
    }
  }
  return refs;
}

/** Si el .js trae "//# sourceMappingURL=...", intenta bajar el .map y
 *  devuelve los nombres de archivo "sources" (no el contenido completo) como
 *  un solo string. En código minificado, esos nombres de ruta (ej.
 *  "src/api/pedidos.service.ts") suelen revelar endpoints/keywords que el
 *  bundle comprimido oculta, sin tener que desminificar nada. */
async function fetchSourceMapHints(jsSource, jsUrl, fetchImpl, onFetchError) {
  const m = jsSource.match(SOURCEMAP_COMMENT_REGEX);
  if (!m || m[1].startsWith('data:')) return '';
  const mapUrl = resolveUrl(m[1], jsUrl);
  if (!mapUrl) return '';
  const mapText = await safeFetchText(mapUrl, fetchImpl, onFetchError);
  if (!mapText) return '';
  try {
    const map = JSON.parse(mapText);
    const sources = Array.isArray(map.sources) ? map.sources : [];
    return sources.join('\n');
  } catch {
    return '';
  }
}

async function seedUrlsFromRobots(origin, fetchImpl, onFetchError) {
  const found = new Set();
  const robotsText = await safeFetchText(`${origin}/robots.txt`, fetchImpl, onFetchError);
  if (!robotsText) return found;
  for (const line of robotsText.split('\n')) {
    const m = line.match(/^\s*(?:Disallow|Allow|Sitemap)\s*:\s*(\S+)/i);
    if (!m) continue;
    const abs = resolveUrl(m[1], origin);
    if (abs && looksLikeJs(abs)) found.add(abs);
  }
  return found;
}

/**
 * Descubre TODOS los .js alcanzables a partir de:
 *  - seedJsFiles: lo que ya capturó el crawler dinámico vía requests de red
 *  - pagesHtml: Map<pageUrl, htmlRenderizado> de cada página visitada
 *
 * BFS con límite de concurrencia, profundidad y cantidad total de archivos
 * para no mandar al objetivo una ráfaga de requests ni quedarse colgado en
 * un sitio con cientos de chunks.
 *
 * Devuelve:
 *  - jsFiles: string[]               → todas las URLs de .js encontradas
 *  - sources: Map<jsUrl, string>      → el código ya descargado de cada una
 *                                        (para no tener que re-fetchear al
 *                                        analizarlas después)
 *  - sourceMapHints: Map<jsUrl, string> → nombres de archivo originales
 *                                        sacados del sourcemap, si había
 */
export async function discoverAllJsFiles(
  startUrl,
  {
    seedJsFiles = [],
    pagesHtml = new Map(),
    fetchImpl = fetch,
    maxJsFiles = 150,
    maxDepth = 6,
    concurrency = 5,
    followSourceMaps = true,
    followRobots = true,
    onFetchError = null, // (url, reason) => void — para diagnosticar fallos en vez de tragárselos
  } = {}
) {
  const origin = new URL(startUrl).origin;
  const visited = new Set();
  const sources = new Map();
  const sourceMapHints = new Map();
  const queue = [];
  const pushSeed = (u) => {
    const abs = resolveUrl(u, startUrl);
    if (abs) queue.push({ url: abs, depth: 0 });
  };

  for (const u of seedJsFiles) pushSeed(u);
  for (const [pageUrl, html] of pagesHtml.entries()) {
    for (const ref of extractJsRefsFromHtml(html, pageUrl)) pushSeed(ref);
  }
  if (followRobots) {
    for (const ref of await seedUrlsFromRobots(origin, fetchImpl, onFetchError)) pushSeed(ref);
  }

  while (queue.length && visited.size < maxJsFiles) {
    const batch = [];
    while (batch.length < concurrency && queue.length && visited.size + batch.length < maxJsFiles) {
      const item = queue.shift();
      if (visited.has(item.url) || batch.some((b) => b.url === item.url)) continue;
      batch.push(item);
    }
    if (!batch.length) break;

    const results = await Promise.all(
      batch.map(async (item) => ({ item, source: await safeFetchText(item.url, fetchImpl, onFetchError) }))
    );

    for (const { item, source } of results) {
      visited.add(item.url);
      if (!source) continue;
      sources.set(item.url, source);

      if (followSourceMaps) {
        const hints = await fetchSourceMapHints(source, item.url, fetchImpl, onFetchError);
        if (hints) sourceMapHints.set(item.url, hints);
      }

      if (item.depth >= maxDepth) continue;
      for (const ref of extractJsRefsFromJs(source, item.url)) {
        if (!visited.has(ref)) queue.push({ url: ref, depth: item.depth + 1 });
      }
    }
  }

  return { jsFiles: [...visited], sources, sourceMapHints };
}
